Fut is written and maintained by Piotr Staroszczyk and various contributors:

Development Lead
````````````````

- Piotr Staroszczyk <piotr.staroszczyk@get24.org>


EAHashingAlgorithm
``````````````````

- Danny Cullen @dcullen88


Patches and Suggestions
```````````````````````
- mvillarejo
- Mauro Marano
- Innursery
- Arthur Nogueira Neves @arthurnn
- jamslater
- rjansen
- ricklhp7
- hunterjm
